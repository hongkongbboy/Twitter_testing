//
//  TweetViewController.swift
//  Twitter
//
//  Created by kin on 2/25/19.
//  Copyright © 2019 Dan. All rights reserved.
//

import UIKit

class TweetViewController: UIViewController, UITextViewDelegate {

    
    @IBOutlet weak var tweetTextView: UITextView!
    @IBOutlet weak var charsLeftLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tweetTextView.becomeFirstResponder()

        // Do any additional setup after loading the view.
        charsLeftLabel.text = "140"
    }
    
    @IBAction func cancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func tweet(_ sender: Any) {
        if (!tweetTextView.text.isEmpty){
            TwitterAPICaller.client?.postTweet(tweetString: tweetTextView.text, success: {
                self.dismiss(animated: true, completion: nil)
                
            }, failure: {(error) in
                    print("Error Posting tweet \(error)")
                    self.dismiss(animated: true, completion: nil)
            })
        } else {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    func checkRemainingChars() {
        
        let characterLimit = 140
        
        let charsInTextView = -tweetTextView.text.characters.count
        
        let remainingChars = characterLimit + charsInTextView
        
        if remainingChars < characterLimit {
            
            charsLeftLabel.textColor = UIColor.black
            
        }
        
        if remainingChars <= 20 {
            
            charsLeftLabel.textColor = UIColor.orange
            
        }
        
        if remainingChars <= 10 {
            
            charsLeftLabel.textColor = UIColor.red
            
        }
        
        charsLeftLabel.text = String(remainingChars)
        
        print(remainingChars)
        
    }
    
    func textViewDidChange(_ textView: UITextView) {
        checkRemainingChars()
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
